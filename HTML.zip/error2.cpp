#include<stdio.h>

int main()
{
	for(int i=1;i>=1;i++){
		printf("404 ERROR -*- HACKED ");
		return 0;
	}
}

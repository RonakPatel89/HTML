#include<iostream>
using namespace std;

int main()
{
	for(int i=0;i>=1;i++){
		cout<<"404 ERROR -*- HACKED ";
		return 0;
	}
}
